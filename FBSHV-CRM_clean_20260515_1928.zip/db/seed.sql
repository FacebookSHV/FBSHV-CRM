INSERT OR IGNORE INTO workspaces (id, name, slug, created_at)
VALUES ('workspace-demo', 'Shop Huy Vân', 'shop-huy-van', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO users (id, name, email, role, created_at)
VALUES ('user-demo', 'Demo Admin', 'admin@fbshv.local', 'admin', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO workspace_members (id, workspace_id, user_id, role, joined_at)
VALUES ('member-demo', 'workspace-demo', 'user-demo', 'owner', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO pages (id, workspace_id, external_page_id, name, status, token_status, synced_at)
VALUES ('page-demo', 'workspace-demo', 'fb_page_demo', 'Shop Huy Vân', 'mock', 'missing', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO customers (id, workspace_id, name, phone, facebook_id, note, created_at)
VALUES ('customer-demo', 'workspace-demo', 'Nguyễn Minh Anh', '0900000000', 'fb_customer_demo', 'Khách hỏi camera mini', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO conversations (id, workspace_id, page_id, customer_id, channel, status, last_message_at)
VALUES ('conversation-demo', 'workspace-demo', 'page-demo', 'customer-demo', 'messenger', 'open', '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO product_cache
(id, workspace_id, external_product_id, sku, name, category, cost_price, original_price, sale_price, current_price, discount_amount, discount_percent, currency, image_url, description, status, price_updated_at, synced_at)
VALUES
('prod-crm-001', 'workspace-demo', 'prod-crm-001', 'CRM_TEST_001', 'Sản phẩm test CRM', 'Thiết bị thông minh', 7000, 12000, 10000, 10000, 2000, 16.7, 'VND', '', 'Sản phẩm mock dùng để kiểm tra đồng bộ.', 'active', '2026-05-15T03:00:00.000Z', '2026-05-15T04:00:00.000Z');

INSERT OR IGNORE INTO inventory_cache
(id, workspace_id, sku, stock, available_stock, reserved_stock, low_stock_threshold, synced_at)
VALUES ('inv-crm-001', 'workspace-demo', 'CRM_TEST_001', 100, 92, 8, 10, '2026-05-15T04:00:00.000Z');

INSERT OR IGNORE INTO ad_accounts (id, workspace_id, external_account_id, name, status)
VALUES ('ad-account-demo', 'workspace-demo', 'act_mock', 'Tài khoản quảng cáo mock', 'mock');

INSERT OR IGNORE INTO automation_rules (id, workspace_id, name, trigger_type, active, created_at)
VALUES ('rule-demo', 'workspace-demo', 'Cảnh báo tồn thấp', 'inventory.low_stock', 1, '2026-05-15T00:00:00.000Z');

INSERT OR IGNORE INTO audit_logs (id, workspace_id, actor_id, action, entity_type, entity_id, metadata_json, created_at)
VALUES ('audit-demo', 'workspace-demo', 'user-demo', 'product.sync.mock', 'product_cache', 'CRM_TEST_001', '{}', '2026-05-15T00:00:00.000Z');
