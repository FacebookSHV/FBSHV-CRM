# External API + Webhook cho Facebook Ads CRM

## 1. Tổng quan

Trang Quản Lý TMĐT là nguồn dữ liệu gốc cho Product, SKU, Inventory và Order. Facebook Ads CRM chỉ là kênh bán bên ngoài, được phép đọc sản phẩm/tồn kho, giữ hàng, hủy giữ hàng, tạo đơn và đọc trạng thái đơn qua `/api/external/*`. CRM không được tự trừ tồn kho local.

Base URL production:

```text
https://huyvan-worker-api.nghiemchihuy.workers.dev
```

## 2. Authentication

Mọi endpoint `/api/external/*` bắt buộc gửi một trong hai header:

```http
Authorization: Bearer <API_KEY_FOR_FACEBOOK_CRM>
```

hoặc:

```http
X-API-Key: <API_KEY_FOR_FACEBOOK_CRM>
```

Không đưa API key vào query string và không ghi API key vào log.

## 3. Chuẩn response

Thành công:

```json
{
  "success": true,
  "data": {},
  "message": "OK"
}
```

Phân trang:

```json
{
  "success": true,
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 100,
    "totalPages": 2
  }
}
```

Lỗi:

```json
{
  "success": false,
  "error": {
    "code": "INSUFFICIENT_STOCK",
    "message": "Không đủ tồn kho",
    "details": {}
  }
}
```

## 4. Danh sách API

| API | Mục đích |
| --- | --- |
| `GET /api/external/products` | Lấy danh sách sản phẩm |
| `GET /api/external/products/:id` | Lấy chi tiết sản phẩm và biến thể |
| `GET /api/external/products/sku/:sku` | Lấy sản phẩm theo SKU |
| `GET /api/external/products/sku/:sku/price` | Lấy giá mới nhất theo SKU |
| `POST /api/external/inventory/check` | Kiểm tra tồn kho realtime |
| `POST /api/external/inventory/reserve` | Giữ hàng tạm thời |
| `POST /api/external/inventory/reservations/:reservationId/cancel` | Hủy giữ hàng |
| `POST /api/external/inventory/reservations/:reservationId/commit` | Commit giữ hàng và trừ tồn |
| `POST /api/external/orders/from-facebook` | Tạo đơn từ Facebook Ads CRM |
| `GET /api/external/orders/:orderId` | Lấy trạng thái/chi tiết đơn |
| `GET /api/external/orders/source/:sourceOrderId` | Lấy đơn theo mã của CRM |
| `POST /api/external/webhook/test` | Gửi webhook thử |
| `GET /api/external/webhook/deliveries` | Xem log gửi webhook gần nhất |

## 5. Product API

### GET `/api/external/products`

Query hỗ trợ: `page`, `limit`, `search`, `category`, `status`, `updatedSince`, `includeInventory`.

Response trả đủ giá:

```json
{
  "success": true,
  "data": [
    {
      "id": "40TACKE8X60MMK243",
      "platform": "shopee",
      "shopName": "chihuy1984",
      "sku": "40TACKE8X60MMK243",
      "name": "40 Tắc Kê 8mm x 60mm",
      "costPrice": 42000,
      "originalPrice": 139000,
      "salePrice": 90000,
      "currentPrice": 90000,
      "discountAmount": 49000,
      "discountPercent": 35.25,
      "currency": "VND",
      "stock": 211,
      "availableStock": 211,
      "reservedStock": 0,
      "priceUpdatedAt": "2026-05-15T00:00:00.000Z",
      "updatedAt": "2026-05-15T00:00:00.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 100,
    "totalPages": 2
  }
}
```

### GET `/api/external/products/sku/:sku/price`

Facebook Ads CRM nên gọi API này trước khi tư vấn khách hoặc tạo đơn.

```json
{
  "success": true,
  "data": {
    "sku": "40TACKE8X60MMK243",
    "productId": "40TACKE8X60MMK243",
    "variantId": "40TACKE8X60MMK243",
    "name": "40 Tắc Kê 8mm x 60mm",
    "costPrice": 42000,
    "originalPrice": 139000,
    "salePrice": 90000,
    "currentPrice": 90000,
    "discountAmount": 49000,
    "discountPercent": 35.25,
    "currency": "VND",
    "priceUpdatedAt": "2026-05-15T00:00:00.000Z"
  }
}
```

## 6. Inventory API

### POST `/api/external/inventory/check`

```json
{
  "sku": "SP001",
  "quantity": 2
}
```

### POST `/api/external/inventory/reserve`

Nên gửi `Idempotency-Key` để chống retry tạo nhiều phiếu giữ hàng. Nếu không có key, hệ thống vẫn chống trùng theo `source + sourceConversationId + sku + active reservation`.

```json
{
  "sku": "SP001",
  "quantity": 2,
  "source": "facebook_crm",
  "sourceConversationId": "conv_001",
  "sourceCustomerId": "cus_001",
  "expiresInMinutes": 30,
  "note": "Khách đang chốt đơn từ inbox Facebook"
}
```

### POST `/api/external/inventory/reservations/:reservationId/cancel`

```json
{
  "reason": "Khách không xác nhận đơn"
}
```

### POST `/api/external/inventory/reservations/:reservationId/commit`

```json
{
  "orderId": "DHFB260515ABC123"
}
```

## 7. Order API

### POST `/api/external/orders/from-facebook`

`sourceOrderId` là idempotency key chính. Nếu CRM gửi lại cùng `sourceOrderId`, hệ thống trả về đơn đã tạo trước đó, không tạo đơn mới.

```json
{
  "source": "facebook_crm",
  "sourceOrderId": "fbcrm_order_001",
  "sourceConversationId": "conv_001",
  "sourcePageId": "page_001",
  "customer": {
    "name": "Nguyễn Văn A",
    "phone": "0900000000",
    "facebookId": "fb_123",
    "address": "Hà Nội"
  },
  "items": [
    {
      "sku": "SP001",
      "quantity": 2,
      "price": 90000,
      "originalPrice": 139000,
      "salePrice": 90000,
      "currentPrice": 90000,
      "reservationId": "1"
    }
  ],
  "shipping": {
    "address": "Hà Nội",
    "province": "Hà Nội",
    "district": "Cầu Giấy",
    "ward": "Dịch Vọng",
    "shippingFee": 30000
  },
  "payment": {
    "method": "cod",
    "status": "unpaid"
  },
  "note": "Đơn tạo từ inbox Facebook"
}
```

Hệ thống luôn kiểm tra lại `currentPrice` trong Product Master. Nếu giá CRM gửi đã cũ, đơn dùng giá hiện tại và trả `warnings`.

## 8. Webhook gửi sang Facebook Ads CRM

URL nhận webhook lấy từ `FACEBOOK_CRM_WEBHOOK_URL`.

Events:

```text
product.created
product.updated
product.price_updated
product.inactive
inventory.updated
inventory.low_stock
order.created
order.status_changed
order.cancelled
order.completed
order.returned
```

Header bắt buộc:

```http
X-Webhook-Event: inventory.updated
X-Webhook-Id: evt_001
X-Webhook-Timestamp: 2026-05-15T00:00:00.000Z
X-Webhook-Signature: sha256=<hmac_signature>
```

Signature:

```text
HMAC_SHA256(WEBHOOK_SECRET_FOR_FACEBOOK_CRM, rawBody)
```

Ví dụ verify Node.js:

```js
import crypto from 'node:crypto'

function verify(rawBody, headerSignature, secret) {
  const expected = 'sha256=' + crypto
    .createHmac('sha256', secret)
    .update(rawBody)
    .digest('hex')
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(headerSignature))
}
```

Webhook retry tối đa 3 lần. Kết quả ghi ở `webhook_delivery_logs` và xem nhanh qua `GET /api/external/webhook/deliveries`.

## 9. Biến môi trường

Trang Quản Lý TMĐT:

```env
API_KEY_FOR_FACEBOOK_CRM=""
WEBHOOK_SECRET_FOR_FACEBOOK_CRM=""
FACEBOOK_CRM_WEBHOOK_URL=""
```

Facebook Ads CRM:

```env
ECOMMERCE_API_BASE_URL="https://huyvan-worker-api.nghiemchihuy.workers.dev"
ECOMMERCE_API_KEY=""
ECOMMERCE_WEBHOOK_SECRET=""
MOCK_ECOMMERCE_API="false"
```

## 10. Curl test nhanh

```bash
BASE="https://huyvan-worker-api.nghiemchihuy.workers.dev"
KEY="<API_KEY_FOR_FACEBOOK_CRM>"

curl -H "Authorization: Bearer $KEY" "$BASE/api/external/products?limit=5"

curl -X POST "$BASE/api/external/inventory/check" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"sku":"SP001","quantity":2}'

curl -X POST "$BASE/api/external/inventory/reserve" \
  -H "Authorization: Bearer $KEY" \
  -H "Idempotency-Key: conv_001_SP001" \
  -H "Content-Type: application/json" \
  -d '{"sku":"SP001","quantity":2,"source":"facebook_crm","sourceConversationId":"conv_001","sourceCustomerId":"cus_001","expiresInMinutes":30}'
```

## 11. Postman

Import file `docs/facebook-crm-postman-collection.json`, sau đó tạo environment:

```text
baseUrl=https://huyvan-worker-api.nghiemchihuy.workers.dev
apiKey=<API_KEY_FOR_FACEBOOK_CRM>
sku=<SKU_TEST>
reservationId=<RESERVATION_ID>
orderId=<ORDER_ID>
sourceOrderId=<SOURCE_ORDER_ID>
```

## 12. Mã lỗi

```text
UNAUTHORIZED
FORBIDDEN
VALIDATION_ERROR
PRODUCT_NOT_FOUND
SKU_NOT_FOUND
INSUFFICIENT_STOCK
RESERVATION_NOT_FOUND
RESERVATION_EXPIRED
RESERVATION_CANCELLED
RESERVATION_ALREADY_COMMITTED
ORDER_NOT_FOUND
DUPLICATE_SOURCE_ORDER
WEBHOOK_SEND_FAILED
INTERNAL_ERROR
```

## 13. Lưu ý vận hành

- `products` và `product_variations` là nguồn đọc sản phẩm/giá/tồn.
- `inventory_reservations` chỉ giữ phần tồn đang chờ khách chốt, không phải kho riêng.
- `orders_v2` và `order_items` là nguồn đơn hàng chính.
- API tạo đơn dùng giá hiện tại trong Product Master, không để CRM tự quyết định giá cuối.
- Không test `commit` hoặc `orders/from-facebook` trên production bằng SKU thật nếu chưa chốt quy trình hoàn kho/test data.

## 14. Facebook OAuth, Page và webhook trong CRM

Các endpoint CRM đã có:

| API | Mục đích |
| --- | --- |
| `GET /api/facebook/connect` | Redirect sang Facebook OAuth. Mock-mode chỉ redirect callback mock, không gọi Meta. |
| `GET /api/facebook/callback` | Đổi code lấy user token, lấy page list/page token, lưu token đã mã hóa. |
| `GET /api/facebook/pages` | Liệt kê page đã kết nối và trạng thái token/webhook. |
| `POST /api/facebook/pages/:id/subscribe` | Subscribe page vào webhook bằng page token thật. |
| `POST /api/facebook/disconnect` | Ngắt kết nối page/connection an toàn. |
| `GET /api/webhooks/facebook` | Verify webhook bằng `hub.verify_token`. |
| `POST /api/webhooks/facebook` | Verify chữ ký, lưu raw event, parse Messenger/comment, chống duplicate. |
| `POST /api/facebook/messages/send` | Gửi Messenger reply. |
| `POST /api/facebook/comments/reply` | Trả lời comment. |
| `POST /api/facebook/comments/hide` | Ẩn hoặc bỏ ẩn comment. |
| `GET /api/inbox/conversations` | Danh sách hội thoại. |
| `GET /api/inbox/conversations/:id/messages` | Tin nhắn trong hội thoại. |
| `GET /api/comments` | Danh sách comment cần xử lý. |

OAuth scopes xin khi connect Facebook:

```text
pages_show_list
pages_manage_metadata
pages_messaging
pages_read_engagement
pages_manage_engagement
business_management
ads_read
ads_management
```

`ads_read`, `ads_management` và `business_management` dùng cho luồng tài khoản quảng cáo. Khi app còn dev-mode, tài khoản đăng nhập cần là admin/developer/tester của app và có quyền trên Business/ad account. Khi đưa app ra production public, các quyền quảng cáo có thể cần Meta App Review.

Env real-mode:

```env
AUTH_SECRET=""
ENCRYPTION_KEY=""
CRM_APP_URL=""
APP_BASE_URL=""
META_APP_ID=""
META_APP_SECRET=""
META_VERIFY_TOKEN=""
META_GRAPH_API_VERSION="v20.0"
META_REDIRECT_URI="<CRM_APP_URL>/api/facebook/callback"
MOCK_EXTERNAL_APIS="false"
ECOMMERCE_API_BASE_URL="https://huyvan-worker-api.nghiemchihuy.workers.dev"
ECOMMERCE_API_KEY=""
ECOMMERCE_WEBHOOK_SECRET=""
MOCK_ECOMMERCE_API="false"
```

Webhook URL cấu hình trong Facebook App:

```text
<CRM_APP_URL>/api/webhooks/facebook
```

Subscribe fields tối thiểu: `messages`, `messaging_postbacks`, `feed`.

Token Facebook lưu trong D1 chỉ ở dạng encrypted bằng `ENCRYPTION_KEY`; không ghi page/user token ra log hoặc report.
