-- FBSHV CRM D1 schema entrypoint.
-- NEO: DB schema chính nằm trong src/db/schema và được drizzle-kit generate.
-- Chạy `npm run db:generate` để tạo migration mới trong thư mục drizzle/.
-- Chạy `npm run db:migrate` để apply migration local D1.

SELECT 'FBSHV CRM schema is managed by Drizzle' AS note;
